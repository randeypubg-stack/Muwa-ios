# Muwa Nasheeds — iOS Release Build

This project is native SwiftUI. It does not use WebView, React, HTML, CSS, or Capacitor.

## Current build identity
- Bundle ID: `app.muwa.nasheeds`
- Display name: `Muwa Nasheeds`
- Version: `1.4.0`
- Build: `8`
- Deployment target: iOS/iPadOS 17+
- Devices: iPhone + iPad
- iPhone orientations: portrait + landscape left/right
- iPad orientations: portrait + upside-down + landscape left/right
- Background audio mode: enabled
- Privacy manifest: included
- AppIcon: opaque 1024×1024 asset included

## Before opening Xcode
Run the repository audit:

```bash
./verify_project.sh
```

## Open and run
1. Open `MuwaNasheeds.xcodeproj` in Xcode 16 or newer.
2. Select target `MuwaNasheeds`.
3. Signing & Capabilities → choose your Apple Developer Team.
4. Keep Automatically manage signing enabled.
5. Pick an iPhone/iPad device or simulator and Run.

## Create a signed archive / IPA
1. Select `Any iOS Device (arm64)` / `Generic iOS Device`.
2. Product → Archive.
3. Organizer → select the archive → Distribute App.
4. Choose TestFlight/App Store, Ad Hoc, or Development as appropriate.
5. Let Xcode resolve signing/provisioning and export where supported.

## External production checks
These are not source-code problems but require Apple/Floot account-side access:
- Ensure App Store Connect contains the two StoreKit product IDs used by `PremiumManager`.
- Publish the latest Floot backend revision to `https://muwa-app.floot.app`. Until then, Release has a controlled fallback to the current sandbox API for unavailable endpoints.
- When Floot editing is available again, require authentication server-side in `publicationUpload` as defense-in-depth (the native UI already requires an authenticated user).
- If password reset is desired, configure a real transactional email provider first; the app intentionally does not show a fake reset action.

## Final hardware QA
Before App Store submission, test at least:
- iPhone portrait and landscape
- iPad mini / 11-inch / 13-inch portrait and landscape
- iPad Split View and Stage Manager
- account create/login/logout and relaunch session restore
- streaming, seek, shuffle/repeat, interruption and headphone removal
- Premium purchase/restore with StoreKit sandbox account
- app background / screen lock Premium behavior
- offline download/use/removal and expired-Premium behavior
- AirPlay route selection
- subtitles in AR/RU/EN
- publication audio/cover upload

A real signed IPA can only be compiled/linked and signed on macOS with Xcode and an Apple signing identity/provisioning profile.
