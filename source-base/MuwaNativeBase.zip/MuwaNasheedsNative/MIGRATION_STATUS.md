# Migration status — native SwiftUI v8

## Native migration complete
- 100% SwiftUI interface: no WebView, React, HTML, CSS or Capacitor UI.
- Native Home, Search, Library, Profile, Premium, auth, player, queue, subtitles and publication flow.
- Real Muwa catalog with seven audio/cover CDN sources.
- Native AVPlayer playback, seeking, queue, shuffle, repeat, artwork swipe and Now Playing metadata.
- Audio interruption and headphone-route handling.
- iPhone/iPad adaptive layouts, phone landscape split compositions, iPad multitasking widths.
- Persistent favorites, history, playlist, queue and local publication state.
- Native email/password auth with restore/logout and guest listening.
- Native StoreKit 2 Premium entitlement flow.
- Premium-gated background/lock-screen behavior, subtitles, offline use/downloads and in-app AirPlay picker.
- Subtitle/transcription API client with local cache and word timings.
- Private direct-to-storage publication uploads with completion metadata.
- AppIcon/AppMark synchronized byte-for-byte to the configured Floot 1024×1024 opaque production icon (SHA-256 `ac533d8fe8db72557b1c2a27f8986895dc9edb387709141e632dad82b68a9af5`).
- Profile no longer duplicates Library destinations.

## v8 reliability audit fixes
- Production API is primary in Release, with narrowly scoped fallback for unavailable endpoint/server statuses.
- Auth remembers the backend host that actually created/restored the session, preventing cross-host restore inconsistencies.
- Logout clears known production and sandbox sessions to prevent stale-cookie re-login.
- HTTP auth/validation errors do not incorrectly fall through to another backend.
- Subtitle/publication fallback is limited to transport errors and explicitly unavailable server statuses.
- Offline files are excluded from backup.
- Expired/non-Premium users cannot continue consuming the local offline copy; streaming remains available normally.
- End-of-queue state is corrected and finished tracks can restart cleanly.
- Free background playback is stopped; interrupted playback cannot auto-resume in background without Premium.
- Misleading Premium claims for CarPlay/separate “maximum audio quality” were removed.
- About screen version/build is read dynamically from the bundle.
- Registration/login validation and copy were cleaned up.
- Full Swift source tree was formatted with `swift-format` and re-parsed.

## Account-side tasks remaining before App Store release
- Republish the latest backend revision to the production Floot host. The app has a temporary controlled sandbox fallback so current native testing can continue.
- Harden `publicationUpload` server-side with authenticated-session enforcement once Floot edits are available again; the native client already gates publication by auth.
- Create/verify StoreKit products in App Store Connect.
- Add real password-reset email only after a transactional email provider is configured.
- Run a true Xcode compile/link/archive and real-device QA on macOS; Linux cannot load Apple SDK frameworks.
