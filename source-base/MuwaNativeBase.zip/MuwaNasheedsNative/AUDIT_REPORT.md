# Muwa Nasheeds — v8 release audit report

**Audit date:** 19 September 2026  
**Target:** native SwiftUI iOS/iPadOS project  
**Bundle ID:** `app.muwa.nasheeds`  
**Version / build:** `1.4.0 (8)`  
**Deployment target:** iOS/iPadOS 17+  

## Executive result

The project passes every static/source-level check available in the current Linux environment. All 39 Swift sources parse successfully, `swift-format lint` is clean, plist/Xcode project/asset JSON files are valid, every Swift file is referenced by the Xcode project, required resources are in the Resources build phase, the app icon is a real opaque 1024×1024 PNG, and no WebView/browser UI is present.

A true iOS compile/link/archive cannot be honestly claimed here because Apple SDK frameworks and `xcodebuild` exist only on macOS/Xcode. The final section lists the remaining account/runtime checks separately so they are not confused with source defects.

## Fixes applied in this audit

- AppIcon/AppMark synchronized to the exact configured Floot production icon: opaque 1024×1024 PNG with the silver-blue Muwa mark on black; Xcode AppIcon build setting points to it.
- Release backend policy keeps production primary and falls back to the current sandbox only for transport failures or explicit endpoint/server-unavailable statuses.
- Authentication now remembers the backend host that actually authenticated/restored the user, so a sandbox fallback session survives relaunch consistently.
- Authentication no longer falls through to a second backend after real 401/409/429 validation/auth failures.
- Logout attempts to clear sessions on every known backend host, preventing an old production/sandbox cookie from silently reviving a session later.
- Subtitle and publication services now fall back only on transport/unavailable-server conditions, not on ordinary API errors.
- Publication submission performs its own authenticated-session preflight in addition to the UI auth gate.
- Offline audio files are excluded from device backup.
- If Premium expires, the player stops consuming the saved offline copy and falls back to normal streaming; downloaded bytes can still be removed from Downloads.
- End-of-queue playback state/restart behavior was corrected.
- Phone-call/audio interruptions and unplugged-headphone route changes pause correctly; free playback cannot auto-resume in the background after an interruption.
- Free users are stopped when the app goes to background; Premium controls background/Lock Screen behavior.
- Premium copy no longer claims CarPlay or a separate maximum-quality audio tier that is not implemented.
- Profile no longer duplicates Library destinations.
- About screen reads version/build from the bundle instead of a stale hard-coded version.
- Email validation was tightened and user-facing development/mockup wording was removed.
- Every Swift source was normalized with `swift-format` and re-verified afterward.

## Verification results

| Area | Status | Result |
|---|---|---|
| Swift syntax | **PASS** | 39 / 39 `.swift` files parsed with Swift 6.2.1 parser. |
| Swift formatting/lint | **PASS** | `swift-format lint --recursive Sources` returned exit 0 with zero diagnostics. |
| Info.plist | **PASS** | `plutil -lint`. |
| Privacy manifest | **PASS** | `plutil -lint`; tracking disabled; UserDefaults required-reason entry present. |
| Xcode project.pbxproj | **PASS** | `plutil -lint`. |
| Asset catalog JSON | **PASS** | All 4 `Contents.json` files parse. |
| Xcode source membership | **PASS** | All 39 Swift basenames are present in the Xcode project; no duplicate basenames. |
| Resource membership | **PASS** | `Assets.xcassets` and `PrivacyInfo.xcprivacy` are in the Resources build phase. |
| Native-only UI | **PASS** | No `WKWebView`, `WebView`, `SFSafariViewController`, React, HTML page, or JavaScript UI reference in `Sources/`. |
| Transport URLs | **PASS** | All application source URLs are HTTPS. |
| App icon | **PASS** | 1024×1024 opaque RGB PNG; exact Floot-source SHA-256 `ac533d8fe8db72557b1c2a27f8986895dc9edb387709141e632dad82b68a9af5`. |
| Bundle ID | **PASS** | `app.muwa.nasheeds` in Debug and Release target settings. |
| Version/build | **PASS** | `1.4.0 (8)` in project spec and Xcode project. |
| Device family | **PASS** | `TARGETED_DEVICE_FAMILY = 1,2` (iPhone + iPad). |
| Orientations | **PASS** | iPhone portrait + landscape L/R; iPad portrait/upside-down + landscape L/R. |
| Background audio declaration | **PASS** | `UIBackgroundModes` contains `audio`. |
| Signing configuration | **PASS** | Automatic signing configured; Team/profile must be selected on the owner’s Mac. |
| Linux Xcode compile/link | **NOT POSSIBLE** | `xcodebuild`/Apple iOS SDK is not installed in this Linux environment. |

## Functional review by subsystem

| Subsystem | Status | Notes |
|---|---|---|
| Launch/root navigation | **Code-verified** | Auth check → auth flow/guest/authenticated app; four bottom destinations remain Главная · Плеер · Библиотека · Профиль; mini-player stays above bottom bar. |
| Authentication | **Code-verified** | Registration, login, cookie session restore, guest mode, logout, normalized email, rate-limit/error messaging; production/sandbox session host consistency fixed. |
| Password reset / social login | **Intentionally not exposed** | The approved visual reference contained conceptual reset/Apple/Google controls, but production code does not show dead buttons because no real email/OAuth provider is configured yet. |
| Home/search | **Code-verified** | Native SwiftUI catalog/discovery and search; no browser navigation. |
| Player | **Code-verified** | AVPlayer streaming/offline selection, seek, queue next/previous, shuffle/repeat, swipe cover, end-of-list handling, interruption/route handling. |
| Now Playing / Lock Screen | **Code-verified** | Metadata/commands implemented; Premium gates remote commands/background continuation in app logic. |
| Library | **Code-verified** | Favorites/history/playlist/publications/drafts/downloads are contained in Library; Profile duplication removed. |
| Offline downloads | **Code-verified** | Real files, removal, backup exclusion, Premium download/use gate; no fake downloaded rows. |
| Subtitles | **Code-verified** | ASR endpoint client, AR/RU/EN, word timings, disk cache, Premium gate. |
| Premium / StoreKit | **Code-verified, account setup required** | StoreKit 2 code uses monthly/yearly IDs, purchase/restore/current entitlements; product existence must be verified in App Store Connect. |
| AirPlay | **Code-verified** | Native AVRoutePickerView is present and the in-app route control is Premium-gated. |
| Publications | **Code-verified client** | Native file importer + auth gates + private presigned uploads + submission commit marker. Server-side auth enforcement still needs the post-limit Floot backend edit. |
| iPhone landscape | **Code-verified layout** | Width/height-driven split player/auth layouts; controls are not individually repositioned arbitrarily. |
| All iPads | **Code-verified layout** | iPad family enabled; width-driven layouts cover portrait/landscape, Split View and Stage Manager. |

## Swift file inventory

Every file below passed `swiftc -parse` and `swift-format lint`:

- `Sources/App/MuwaNasheedsApp.swift` — App lifecycle, environment objects, scene-phase playback policy.
- `Sources/App/RootView.swift` — Root auth/app routing, main tabs, mini-player/bottom chrome.
- `Sources/Models/AuthUser.swift` — Authenticated-user data model.
- `Sources/Models/Publication.swift` — Publication/draft status model.
- `Sources/Models/SubtitleModels.swift` — Timed subtitle/translation models.
- `Sources/Models/Track.swift` — Seven-track catalog and CDN sources.
- `Sources/Services/AuthManager.swift` — Auth/guest UI state and session restore orchestration.
- `Sources/Services/AuthService.swift` — Cookie auth client, production/sandbox fallback and logout hygiene.
- `Sources/Services/BackendConfig.swift` — Production/sandbox API host policy.
- `Sources/Services/DownloadManager.swift` — Real offline file storage/removal; backup exclusion.
- `Sources/Services/LibraryStore.swift` — Favorites/history/playlist/queue/publication persistence.
- `Sources/Services/PlayerManager.swift` — AVPlayer, Now Playing, premium background/remote controls, interruptions.
- `Sources/Services/PremiumManager.swift` — StoreKit 2 products, purchases, restore and entitlements.
- `Sources/Services/PublicationUploadService.swift` — Authenticated private presigned publication uploads.
- `Sources/Services/SubtitleManager.swift` — Transcription API, caching and fallback handling.
- `Sources/Theme/AdaptiveLayout.swift` — Width-driven iPhone/iPad/landscape/multitasking geometry.
- `Sources/Theme/Theme.swift` — Native SwiftUI visual system.
- `Sources/Views/Auth/AuthComponents.swift` — Native auth fields/cards/shared components.
- `Sources/Views/Auth/AuthFlowView.swift` — Welcome/login/register adaptive auth flow.
- `Sources/Views/Auth/LoginView.swift` — Native login form and validation.
- `Sources/Views/Auth/RegisterView.swift` — Native registration form and validation.
- `Sources/Views/Auth/RegistrationSuccessView.swift` — Post-registration confirmation screen.
- `Sources/Views/Components/AirPlayButton.swift` — Native AVRoutePickerView bridge.
- `Sources/Views/Components/ArtworkView.swift` — Aspect-fit remote artwork with native fallback.
- `Sources/Views/Components/BottomBar.swift` — Stable four-item bottom navigation.
- `Sources/Views/Components/EmptyStateView.swift` — Reusable native empty-state view.
- `Sources/Views/Components/MiniPlayerView.swift` — Persistent native mini-player.
- `Sources/Views/Components/TrackRow.swift` — Reusable track row.
- `Sources/Views/Home/HomeView.swift` — Native Home/discovery layout.
- `Sources/Views/Library/LibraryDetailView.swift` — Favorites/history/playlist/publications/drafts/downloads.
- `Sources/Views/Library/LibraryView.swift` — Library root/navigation and publication auth gate.
- `Sources/Views/Library/PublicationFlowView.swift` — Native file-import publication workflow.
- `Sources/Views/Player/FullPlayerView.swift` — Portrait/landscape full player, premium gates and gestures.
- `Sources/Views/Player/PlayerSubtitleOverlay.swift` — Timed subtitle overlay on player artwork.
- `Sources/Views/Player/QueueView.swift` — Native queue/reorder UI.
- `Sources/Views/Player/SubtitlePanel.swift` — AR/RU/EN subtitle panel.
- `Sources/Views/Premium/PremiumView.swift` — StoreKit-backed Premium UI and truthful benefits.
- `Sources/Views/Profile/ProfileView.swift` — Account/Premium/settings/about/logout; no Library duplicates.
- `Sources/Views/Search/SearchView.swift` — Native catalog search.

## Xcode / IPA packaging review

- `MuwaNasheeds.xcodeproj` exists and contains Debug + Release settings.
- AppIcon catalog is selected by `ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon`.
- Privacy manifest and asset catalog are included in the Resources build phase.
- Automatic signing is enabled; bundle id is stable.
- No Mac Catalyst target is enabled; device family is iPhone+iPad.
- No camera/microphone/photo-library entitlement is required by the current native file-import flow.
- All application network addresses in source are HTTPS.

## External items that remain before a signed App Store/TestFlight IPA

- **Latest backend production publish:** Floot production is currently published, and its previous native build succeeded, but today’s Floot build-action quota is exhausted. The latest auth/publication backend revision therefore cannot be honestly marked as republished yet. The Release client has a controlled sandbox fallback so current native testing does not depend on pretending production is current.
- **Server defense-in-depth:** `publicationUpload` must require an authenticated server session in Floot itself. The native UI and native service already require auth; server enforcement is scheduled for the first post-quota backend pass.
- **Exact Floot icon comparison:** completed after the Floot limit reset. Configured source `/_cdn/static/158afa48-c82f-461a-bc25-e921d95ea6a0.png` was retrieved as an opaque 1024×1024 PNG and copied byte-for-byte into both AppIcon and AppMark. SHA-256 `ac533d8fe8db72557b1c2a27f8986895dc9edb387709141e632dad82b68a9af5`.
- **StoreKit products:** App Store Connect must contain `app.muwa.nasheeds.premium.monthly` and `app.muwa.nasheeds.premium.yearly`. Source code cannot create App Store Connect products.
- **Real Xcode compile/archive/sign:** requires macOS + Xcode + the owner’s Apple Team/certificate/provisioning. Linux can parse Swift but cannot import/link SwiftUI, AVFoundation, MediaPlayer or StoreKit against the iOS SDK.
- **Real-device QA:** final sign-off still requires an iPhone/iPad run for audio backgrounding, Control Center, AirPlay, StoreKit sandbox purchase, orientation transitions and Stage Manager behavior.

The post-reset follow-up completed the exact configured-icon synchronization. Backend publication verification is recorded separately from the native archive audit because it is a live-service check.

## Final assessment

The native source package is internally consistent and passes all checks that can be performed without Apple’s iOS SDK. No known broken/dead UI action is intentionally exposed: features that require external provider setup (password reset/social login) remain hidden rather than simulated. The remaining release blockers are account-side/runtime verification items, not unparsed source or WebView migration work.
