#!/bin/sh
set -eu
cd "$(dirname "$0")"

printf '%s\n' '== Muwa Nasheeds native project verification =='

printf '%s\n' '[1/8] Parsing every Swift source file…'
find Sources -name '*.swift' -print0 | xargs -0 -n1 swiftc -parse
SWIFT_COUNT=$(find Sources -name '*.swift' | wc -l | tr -d ' ')
printf '  OK — %s Swift files parsed\n' "$SWIFT_COUNT"

printf '%s\n' '[2/8] Validating plist / Xcode project files…'
plutil -lint Info.plist >/dev/null
plutil -lint Resources/PrivacyInfo.xcprivacy >/dev/null
plutil -lint MuwaNasheeds.xcodeproj/project.pbxproj >/dev/null
printf '%s\n' '  OK'

printf '%s\n' '[3/8] Validating asset catalog JSON…'
python3 - <<'PY'
import json
from pathlib import Path
files=list(Path('Resources/Assets.xcassets').rglob('Contents.json'))
for path in files:
    with path.open('r', encoding='utf-8') as f: json.load(f)
print(f'  OK — {len(files)} Contents.json files')
PY

printf '%s\n' '[4/8] Checking AppIcon bytes…'
python3 - <<'PY'
from pathlib import Path
import struct
p=Path('Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png')
b=p.read_bytes()
assert b[:8] == b'\x89PNG\r\n\x1a\n', 'AppIcon is not PNG'
w,h=struct.unpack('>II', b[16:24])
color_type=b[25]
assert (w,h)==(1024,1024), f'AppIcon must be 1024x1024, got {w}x{h}'
assert color_type in (0,2,3), 'AppIcon contains an alpha channel; App Store icon must be opaque'
print(f'  OK — {w}x{h}, opaque PNG')
PY

printf '%s\n' '[5/8] Checking every Swift file is referenced by the Xcode project…'
python3 - <<'PY'
from pathlib import Path
pbx=Path('MuwaNasheeds.xcodeproj/project.pbxproj').read_text(encoding='utf-8')
files=list(Path('Sources').rglob('*.swift'))
missing=[str(p) for p in files if p.name not in pbx]
assert not missing, 'Missing from project: ' + ', '.join(missing)
for resource in ('Assets.xcassets','PrivacyInfo.xcprivacy'):
    assert resource in pbx, f'{resource} is missing from project resources'
print(f'  OK — {len(files)} Swift files + required resources')
PY

printf '%s\n' '[6/8] Checking native-only UI and transport safety…'
if grep -RInE 'WKWebView|\bWebView\b|SFSafariViewController|React|react-dom|<html|javascript:' Sources >/tmp/muwa_web_refs.txt; then
  cat /tmp/muwa_web_refs.txt
  printf '%s\n' 'ERROR: web UI reference found' >&2
  exit 1
fi
if grep -RIn 'http://' Sources >/tmp/muwa_http_refs.txt; then
  cat /tmp/muwa_http_refs.txt
  printf '%s\n' 'ERROR: insecure HTTP URL found in Sources' >&2
  exit 1
fi
printf '%s\n' '  OK — no WebView/browser UI; source network URLs are HTTPS'

printf '%s\n' '[7/8] Checking release identity / device coverage…'
python3 - <<'PY'
from pathlib import Path
pbx=Path('MuwaNasheeds.xcodeproj/project.pbxproj').read_text(encoding='utf-8')
info=Path('Info.plist').read_text(encoding='utf-8')
checks={
 'bundle id':'PRODUCT_BUNDLE_IDENTIFIER = app.muwa.nasheeds;',
 'iPhone+iPad':'TARGETED_DEVICE_FAMILY = "1,2";',
 'app icon':'ASSETCATALOG_COMPILER_APPICON_NAME = AppIcon;',
 'automatic signing':'CODE_SIGN_STYLE = Automatic;',
 'iOS 17':'IPHONEOS_DEPLOYMENT_TARGET = 17.0;',
 'version 1.4.0':'MARKETING_VERSION = 1.4.0;',
 'build 8':'CURRENT_PROJECT_VERSION = 8;',
}
for label,needle in checks.items(): assert needle in pbx, f'Missing {label}'
for orientation in ('UIInterfaceOrientationPortrait','UIInterfaceOrientationLandscapeLeft','UIInterfaceOrientationLandscapeRight'):
    assert orientation in info, f'Missing orientation {orientation}'
assert '<string>audio</string>' in info, 'Background audio mode missing'
print('  OK — bundle/version/signing/device/orientation/background-audio settings present')
PY

printf '%s\n' '[8/8] Optional Xcode build-system check…'
if command -v xcodebuild >/dev/null 2>&1; then
  xcodebuild -project MuwaNasheeds.xcodeproj -scheme MuwaNasheeds -showBuildSettings >/dev/null
  printf '%s\n' '  OK — Xcode can load project/scheme'
else
  printf '%s\n' '  SKIPPED — xcodebuild is not available on this machine (requires macOS/Xcode)'
fi

printf '%s\n' 'VERIFICATION PASSED'
