import SwiftUI
import UIKit

struct AdaptiveLayout {
  let size: CGSize
  let safeArea: EdgeInsets

  var isPad: Bool { UIDevice.current.userInterfaceIdiom == .pad }
  var isLandscape: Bool { size.width > size.height }
  var isCompactLandscapePhone: Bool { !isPad && isLandscape && size.height < 520 }

  // Width-driven on purpose: iPad Split View / Stage Manager can be as narrow as a phone.
  var isWide: Bool { size.width >= 700 }
  var isExtraWide: Bool { size.width >= 1000 }

  var horizontalPadding: CGFloat {
    if size.width < 600 { return isLandscape ? 22 : 18 }
    if size.width >= 1000 { return 40 }
    return 28
  }

  var contentMaxWidth: CGFloat {
    if size.width >= 1000 { return min(size.width - horizontalPadding * 2, 1180) }
    if size.width >= 700 { return min(size.width - horizontalPadding * 2, 980) }
    return min(size.width - horizontalPadding * 2, 620)
  }

  var playerUsesSplitLayout: Bool {
    size.width >= 700 && (isPad || isLandscape)
  }

  var playerArtworkSize: CGFloat {
    if isPad {
      return min(420, size.height * 0.48, size.width * (playerUsesSplitLayout ? 0.38 : 0.68))
    }
    if isLandscape { return min(300, size.height * 0.57, size.width * 0.38) }
    return min(310, size.width * 0.68)
  }

  var libraryColumns: Int {
    if size.width >= 1000 { return 4 }
    if size.width >= 700 { return 4 }
    if size.width >= 560 { return 3 }
    return 2
  }

  var homeRecommendationColumns: Int {
    if size.width >= 1000 { return 4 }
    if size.width >= 700 { return 3 }
    return 2
  }

  var listColumns: Int {
    size.width >= 900 ? 2 : 1
  }

  var bottomChromeMaxWidth: CGFloat {
    if size.width >= 700 { return 720 }
    if isLandscape { return 680 }
    return .infinity
  }

  var authUsesSplitLayout: Bool {
    size.width >= 780 || (isLandscape && size.width >= 620 && size.height <= 620)
  }

  var authFormMaxWidth: CGFloat {
    if isCompactLandscapePhone { return 390 }
    if isPad { return 460 }
    return 430
  }
}

struct AdaptiveFrame: ViewModifier {
  let maxWidth: CGFloat

  func body(content: Content) -> some View {
    content
      .frame(maxWidth: maxWidth)
      .frame(maxWidth: .infinity, alignment: .center)
  }
}

extension View {
  func adaptiveFrame(maxWidth: CGFloat) -> some View {
    modifier(AdaptiveFrame(maxWidth: maxWidth))
  }
}
