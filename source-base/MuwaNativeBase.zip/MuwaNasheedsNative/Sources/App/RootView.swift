import SwiftUI

struct RootView: View {
  @EnvironmentObject private var player: PlayerManager
  @EnvironmentObject private var auth: AuthManager
  @State private var selection: AppTab = .home
  @State private var fullPlayerPresented = false
  @State private var searchPresented = false
  @State private var requestedLibraryDestination: LibraryDestination?

  var body: some View {
    ZStack {
      if auth.registrationJustCompleted {
        RegistrationSuccessView()
          .transition(.opacity.combined(with: .scale(scale: 0.985)))
      } else {
        switch auth.state {
        case .checking:
          LaunchGateView()
            .transition(.opacity)
        case .signedOut:
          AuthFlowView()
            .transition(.opacity)
        case .guest, .authenticated:
          appShell
            .transition(.opacity)
        }
      }
    }
    .animation(.easeInOut(duration: 0.24), value: auth.state)
    .animation(.easeInOut(duration: 0.24), value: auth.registrationJustCompleted)
    .fullScreenCover(isPresented: $fullPlayerPresented) {
      FullPlayerView(selection: $selection)
    }
    .fullScreenCover(isPresented: $searchPresented) {
      SearchView(openPlayer: {
        searchPresented = false
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.18) {
          fullPlayerPresented = true
        }
      })
    }
  }

  private var appShell: some View {
    GeometryReader { proxy in
      let layout = AdaptiveLayout(size: proxy.size, safeArea: proxy.safeAreaInsets)

      ZStack {
        AppBackground().ignoresSafeArea()

        Group {
          switch selection {
          case .home:
            HomeView(
              openPlayer: { fullPlayerPresented = true },
              openSearch: { searchPresented = true }
            )
          case .library:
            LibraryView(
              requestedDestination: $requestedLibraryDestination,
              openSearch: { searchPresented = true }
            )
          case .profile:
            ProfileView(
              openSearch: { searchPresented = true }
            )
          }
        }
        .transition(.opacity)
      }
      .safeAreaInset(edge: .bottom, spacing: 10) {
        VStack(spacing: 10) {
          if player.currentTrack != nil {
            MiniPlayerView(openPlayer: { fullPlayerPresented = true })
          }
          BottomBar(
            selection: $selection,
            playerActive: false,
            openPlayer: { fullPlayerPresented = true }
          )
        }
        .frame(maxWidth: layout.bottomChromeMaxWidth)
        .padding(.horizontal, layout.horizontalPadding)
        .padding(.bottom, layout.isCompactLandscapePhone ? 4 : 10)
        .frame(maxWidth: .infinity)
      }
    }
  }
}

private struct LaunchGateView: View {
  var body: some View {
    ZStack {
      AppBackground().ignoresSafeArea()
      VStack(spacing: 16) {
        Image("AppMark")
          .resizable()
          .scaledToFit()
          .frame(width: 94, height: 94)
          .clipShape(RoundedRectangle(cornerRadius: 27, style: .continuous))
          .shadow(color: .blue.opacity(0.18), radius: 24, y: 12)
        ProgressView()
          .tint(.white.opacity(0.75))
      }
    }
  }
}

enum AppTab: Hashable {
  case home, library, profile
}
