import Foundation

@MainActor
final class DownloadManager: ObservableObject {
  @Published private(set) var downloadedIDs: Set<String>
  @Published private(set) var downloadingIDs: Set<String> = []
  @Published private(set) var lastError: String?

  private let defaults: UserDefaults
  private let fileManager: FileManager

  private enum Key {
    static let downloaded = "muwa.native.downloaded"
  }

  init(defaults: UserDefaults = .standard, fileManager: FileManager = .default) {
    self.defaults = defaults
    self.fileManager = fileManager
    downloadedIDs = Set(defaults.stringArray(forKey: Key.downloaded) ?? [])
  }

  func isDownloaded(_ track: Track) -> Bool {
    guard downloadedIDs.contains(track.id), let url = localURL(for: track) else { return false }
    return fileManager.fileExists(atPath: url.path)
  }

  func localURL(for track: Track) -> URL? {
    guard let folder = try? offlineFolder() else { return nil }
    let ext = track.audioURL.pathExtension.isEmpty ? "mp3" : track.audioURL.pathExtension
    return folder.appendingPathComponent("\(track.id).\(ext)")
  }

  func download(_ track: Track) async throws {
    if isDownloaded(track) { return }
    downloadingIDs.insert(track.id)
    lastError = nil
    defer { downloadingIDs.remove(track.id) }

    do {
      let (temporaryURL, response) = try await URLSession.shared.download(from: track.audioURL)
      guard let http = response as? HTTPURLResponse, (200..<300).contains(http.statusCode) else {
        throw URLError(.badServerResponse)
      }
      guard let destination = localURL(for: track) else { throw URLError(.cannotCreateFile) }
      if fileManager.fileExists(atPath: destination.path) {
        try fileManager.removeItem(at: destination)
      }
      try fileManager.moveItem(at: temporaryURL, to: destination)
      downloadedIDs.insert(track.id)
      defaults.set(Array(downloadedIDs), forKey: Key.downloaded)
    } catch {
      lastError = error.localizedDescription
      throw error
    }
  }

  func remove(_ track: Track) throws {
    if let url = localURL(for: track), fileManager.fileExists(atPath: url.path) {
      try fileManager.removeItem(at: url)
    }
    downloadedIDs.remove(track.id)
    defaults.set(Array(downloadedIDs), forKey: Key.downloaded)
  }

  private func offlineFolder() throws -> URL {
    let base = try fileManager.url(
      for: .applicationSupportDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let folder = base.appendingPathComponent("OfflineAudio", isDirectory: true)
    try fileManager.createDirectory(at: folder, withIntermediateDirectories: true)
    var values = URLResourceValues()
    values.isExcludedFromBackup = true
    var mutableFolder = folder
    try? mutableFolder.setResourceValues(values)
    return folder
  }
}
