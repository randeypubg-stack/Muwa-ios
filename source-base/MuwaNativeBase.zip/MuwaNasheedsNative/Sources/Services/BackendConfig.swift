import Foundation

enum BackendConfig {
  static let sandboxAPIBaseURL = URL(
    string: "https://20d2f317-3710-4331-80ee-ea6072056928.sandbox.floot.app")!
  static let productionAPIBaseURL = URL(string: "https://muwa-app.floot.app")!

  #if DEBUG
    static let apiBaseURL = sandboxAPIBaseURL
    static let candidateAPIBaseURLs = [sandboxAPIBaseURL, productionAPIBaseURL]
  #else
    static let apiBaseURL = productionAPIBaseURL
    // Production remains authoritative. Sandbox is a temporary safety fallback while
    // a newly changed backend is waiting for the next Floot production publish.
    static let candidateAPIBaseURLs = [productionAPIBaseURL, sandboxAPIBaseURL]
  #endif

  static func shouldTryFallback(statusCode: Int) -> Bool {
    statusCode == 404 || statusCode == 405 || statusCode == 502 || statusCode == 503
      || statusCode == 504
  }
}
