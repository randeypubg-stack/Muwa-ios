import Foundation
import SwiftUI

@MainActor
final class LibraryStore: ObservableObject {
  @Published private(set) var likedIDs: Set<String>
  @Published private(set) var historyIDs: [String]
  @Published private(set) var playlistIDs: [String]
  @Published private(set) var queueIDs: [String]
  @Published private(set) var publications: [PublicationDraft]

  private let defaults: UserDefaults

  private enum Key {
    static let liked = "muwa.native.liked"
    static let history = "muwa.native.history"
    static let playlist = "muwa.native.playlist"
    static let queue = "muwa.native.queue"
    static let publications = "muwa.native.publications"
  }

  init(defaults: UserDefaults = .standard) {
    self.defaults = defaults
    likedIDs = Set(defaults.stringArray(forKey: Key.liked) ?? [])
    historyIDs = defaults.stringArray(forKey: Key.history) ?? []
    playlistIDs = defaults.stringArray(forKey: Key.playlist) ?? []
    let savedQueue = defaults.stringArray(forKey: Key.queue) ?? []
    queueIDs = savedQueue.isEmpty ? Track.catalog.map(\.id) : savedQueue

    if let data = defaults.data(forKey: Key.publications),
      let decoded = try? JSONDecoder().decode([PublicationDraft].self, from: data)
    {
      publications = decoded
    } else {
      publications = []
    }
  }

  var favoriteTracks: [Track] { tracks(for: Array(likedIDs)) }
  var historyTracks: [Track] { tracks(for: historyIDs) }
  var playlistTracks: [Track] { tracks(for: playlistIDs) }
  var queueTracks: [Track] { tracks(for: queueIDs) }
  var drafts: [PublicationDraft] { publications.filter { $0.status == .draft } }

  func isLiked(_ track: Track) -> Bool { likedIDs.contains(track.id) }
  func isInPlaylist(_ track: Track) -> Bool { playlistIDs.contains(track.id) }

  func toggleLike(_ track: Track) {
    if likedIDs.contains(track.id) { likedIDs.remove(track.id) } else { likedIDs.insert(track.id) }
    persistLiked()
  }

  func togglePlaylist(_ track: Track) {
    if let index = playlistIDs.firstIndex(of: track.id) {
      playlistIDs.remove(at: index)
    } else {
      playlistIDs.append(track.id)
    }
    defaults.set(playlistIDs, forKey: Key.playlist)
  }

  func recordHistory(_ track: Track) {
    historyIDs.removeAll(where: { $0 == track.id })
    historyIDs.insert(track.id, at: 0)
    if historyIDs.count > 40 { historyIDs = Array(historyIDs.prefix(40)) }
    defaults.set(historyIDs, forKey: Key.history)
  }

  func addNext(_ track: Track, after current: Track?) {
    queueIDs.removeAll(where: { $0 == track.id })
    if let current, let index = queueIDs.firstIndex(of: current.id) {
      queueIDs.insert(track.id, at: min(index + 1, queueIDs.count))
    } else {
      queueIDs.insert(track.id, at: 0)
    }
    persistQueue()
  }

  func removeFromQueue(_ track: Track) {
    queueIDs.removeAll(where: { $0 == track.id })
    persistQueue()
  }

  func moveQueue(fromOffsets source: IndexSet, toOffset destination: Int) {
    queueIDs.move(fromOffsets: source, toOffset: destination)
    persistQueue()
  }

  func ensureQueueContains(_ track: Track) {
    if !queueIDs.contains(track.id) {
      queueIDs.append(track.id)
      persistQueue()
    }
  }

  func addPublication(_ draft: PublicationDraft) {
    publications.insert(draft, at: 0)
    persistPublications()
  }

  func updatePublication(_ draft: PublicationDraft) {
    if let index = publications.firstIndex(where: { $0.id == draft.id }) {
      publications[index] = draft
    } else {
      publications.insert(draft, at: 0)
    }
    persistPublications()
  }

  func deletePublication(_ id: UUID) {
    publications.removeAll(where: { $0.id == id })
    persistPublications()
  }

  func tracks(for ids: [String]) -> [Track] {
    ids.compactMap(Track.track(id:))
  }

  private func persistLiked() {
    defaults.set(Array(likedIDs), forKey: Key.liked)
  }

  private func persistQueue() {
    defaults.set(queueIDs, forKey: Key.queue)
  }

  private func persistPublications() {
    if let data = try? JSONEncoder().encode(publications) {
      defaults.set(data, forKey: Key.publications)
    }
  }
}
