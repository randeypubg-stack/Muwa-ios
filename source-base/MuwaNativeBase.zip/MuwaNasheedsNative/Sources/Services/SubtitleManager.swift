import Combine
import Foundation

@MainActor
final class SubtitleManager: ObservableObject {
  enum LoadState: Equatable {
    case idle
    case loading
    case ready
    case unavailable(String)
  }

  @Published private(set) var segmentsByTrack: [String: [SubtitleSegment]] = [:]
  @Published private(set) var stateByTrack: [String: LoadState] = [:]

  private let apiBaseURL = BackendConfig.apiBaseURL
  private var tasks: [String: Task<Void, Never>] = [:]

  func state(for track: Track) -> LoadState {
    stateByTrack[track.id] ?? .idle
  }

  func segments(for track: Track) -> [SubtitleSegment] {
    segmentsByTrack[track.id] ?? loadCached(trackID: track.id) ?? []
  }

  func load(for track: Track) {
    if segmentsByTrack[track.id] != nil { return }
    if let cached = loadCached(trackID: track.id), !cached.isEmpty {
      segmentsByTrack[track.id] = cached
      stateByTrack[track.id] = .ready
      return
    }
    guard tasks[track.id] == nil else { return }
    guard let src = track.cdnSourcePath else {
      stateByTrack[track.id] = .unavailable(
        "Для этого файла нет поддерживаемого источника субтитров.")
      return
    }

    stateByTrack[track.id] = .loading
    tasks[track.id] = Task { [weak self] in
      guard let self else { return }
      defer { self.tasks[track.id] = nil }
      do {
        let result = try await self.fetch(track: track, src: src)
        guard !Task.isCancelled else { return }
        self.segmentsByTrack[track.id] = result
        self.stateByTrack[track.id] = .ready
        self.saveCache(result, trackID: track.id)
      } catch {
        guard !Task.isCancelled else { return }
        self.stateByTrack[track.id] = .unavailable(error.localizedDescription)
      }
    }
  }

  func activeIndex(for track: Track, time: TimeInterval) -> Int? {
    let values = segments(for: track)
    return values.firstIndex(where: { time >= $0.start && time < $0.end })
  }

  private struct RequestBody: Codable {
    let src: String
    let title: String
    let durationSeconds: Double
    let embeddedLyrics: String?
  }

  private struct Envelope<T: Codable>: Codable {
    let json: T
  }

  private struct ResponseBody: Codable {
    let segments: [SubtitleSegment]
    let source: String
  }

  private struct ErrorBody: Codable {
    let error: String
    let code: String?
  }

  private func fetch(track: Track, src: String) async throws -> [SubtitleSegment] {
    let encoded = try JSONEncoder().encode(
      Envelope(
        json: RequestBody(
          src: src,
          title: track.title,
          durationSeconds: max(track.duration, 1),
          embeddedLyrics: nil
        )))
    let bases = BackendConfig.candidateAPIBaseURLs
    var lastTransportError: Error?

    for (index, baseURL) in bases.enumerated() {
      let url = baseURL.appending(path: "_api/transcribe")
      var request = URLRequest(url: url)
      request.httpMethod = "POST"
      request.setValue("application/json", forHTTPHeaderField: "Content-Type")
      request.timeoutInterval = 180
      request.httpBody = encoded

      let data: Data
      let response: URLResponse
      do {
        (data, response) = try await URLSession.shared.data(for: request)
      } catch {
        lastTransportError = error
        if index < bases.count - 1 { continue }
        throw error
      }

      guard let http = response as? HTTPURLResponse else {
        let error = URLError(.badServerResponse)
        if index < bases.count - 1 {
          lastTransportError = error
          continue
        }
        throw error
      }

      if BackendConfig.shouldTryFallback(statusCode: http.statusCode), index < bases.count - 1 {
        continue
      }
      if (200..<300).contains(http.statusCode) {
        if let wrapped = try? JSONDecoder().decode(Envelope<ResponseBody>.self, from: data) {
          return wrapped.json.segments
        }
        return try JSONDecoder().decode(ResponseBody.self, from: data).segments
      }

      let message: String
      if let wrapped = try? JSONDecoder().decode(Envelope<ErrorBody>.self, from: data) {
        message = wrapped.json.error
      } else if let plain = try? JSONDecoder().decode(ErrorBody.self, from: data) {
        message = plain.error
      } else {
        message = "Субтитры временно недоступны."
      }
      throw NSError(
        domain: "Muwa.Subtitles",
        code: http.statusCode,
        userInfo: [NSLocalizedDescriptionKey: message]
      )
    }

    if let lastTransportError { throw lastTransportError }
    throw URLError(.badServerResponse)
  }

  private func cacheURL(trackID: String) -> URL? {
    FileManager.default.urls(for: .cachesDirectory, in: .userDomainMask).first?
      .appending(path: "muwa-subtitles-\(trackID).json")
  }

  private func loadCached(trackID: String) -> [SubtitleSegment]? {
    guard let url = cacheURL(trackID: trackID),
      let data = try? Data(contentsOf: url),
      let decoded = try? JSONDecoder().decode([SubtitleSegment].self, from: data),
      !decoded.isEmpty
    else { return nil }
    return decoded
  }

  private func saveCache(_ segments: [SubtitleSegment], trackID: String) {
    guard let url = cacheURL(trackID: trackID),
      let data = try? JSONEncoder().encode(segments)
    else { return }
    try? data.write(to: url, options: .atomic)
  }
}
