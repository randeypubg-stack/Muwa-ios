import SwiftUI

struct RegisterView: View {
  @EnvironmentObject private var auth: AuthManager
  @FocusState private var focused: Field?

  let back: () -> Void
  let signIn: () -> Void

  @State private var name = ""
  @State private var email = ""
  @State private var password = ""
  @State private var confirmation = ""
  @State private var revealPassword = false
  @State private var revealConfirmation = false

  private enum Field { case name, email, password, confirmation }

  var body: some View {
    VStack(alignment: .leading, spacing: 18) {
      authHeader(
        title: "Создайте аккаунт",
        subtitle:
          "Откройте аккаунт в Muwa, чтобы сохранять любимые нашиды и пользоваться всеми возможностями приложения",
        back: back)

      VStack(spacing: 12) {
        AuthField(
          title: "Имя",
          icon: "person",
          text: $name,
          contentType: .name,
          keyboard: .default,
          capitalization: .words
        )
        .focused($focused, equals: .name)
        .submitLabel(.next)
        .onSubmit { focused = .email }

        AuthField(
          title: "Email",
          icon: "envelope",
          text: $email,
          contentType: .emailAddress,
          keyboard: .emailAddress
        )
        .focused($focused, equals: .email)
        .submitLabel(.next)
        .onSubmit { focused = .password }

        AuthSecureField(
          title: "Пароль — минимум 8 символов",
          icon: "lock",
          text: $password,
          revealed: $revealPassword
        )
        .focused($focused, equals: .password)
        .submitLabel(.next)
        .onSubmit { focused = .confirmation }

        AuthSecureField(
          title: "Повторите пароль",
          icon: "lock.shield",
          text: $confirmation,
          revealed: $revealConfirmation
        )
        .focused($focused, equals: .confirmation)
        .submitLabel(.go)
        .onSubmit { submit() }
      }

      passwordStatus

      if let error = localError ?? auth.errorMessage {
        AuthErrorMessage(text: error)
      }

      Button(action: submit) {
        HStack(spacing: 9) {
          if auth.isWorking { ProgressView().tint(.black) }
          Text(auth.isWorking ? "Создаём…" : "Зарегистрироваться")
        }
        .font(.headline)
        .foregroundStyle(.black)
        .frame(maxWidth: .infinity)
        .frame(height: 54)
        .background(
          canSubmit ? .white : .white.opacity(0.45),
          in: RoundedRectangle(cornerRadius: 18, style: .continuous))
      }
      .buttonStyle(.plain)
      .disabled(!canSubmit || auth.isWorking)

      Button(action: signIn) {
        HStack(spacing: 4) {
          Text("Уже есть аккаунт?")
            .foregroundStyle(.secondary)
          Text("Войти")
            .fontWeight(.semibold)
        }
        .font(.subheadline)
        .frame(maxWidth: .infinity)
      }
      .buttonStyle(.plain)
    }
    .padding(22)
    .authCard()
    .onAppear { auth.errorMessage = nil }
  }

  private var canSubmit: Bool {
    name.trimmingCharacters(in: .whitespacesAndNewlines).count >= 2 && isValidEmail(email)
      && password.count >= 8 && confirmation == password
  }

  private func isValidEmail(_ value: String) -> Bool {
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    return trimmed.range(
      of: #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#,
      options: [.regularExpression, .caseInsensitive]
    ) != nil
  }

  private var localError: String? {
    if !confirmation.isEmpty && confirmation != password { return "Пароли не совпадают." }
    return nil
  }

  private var passwordStatus: some View {
    HStack(spacing: 8) {
      Image(systemName: password.count >= 8 ? "checkmark.circle.fill" : "circle")
        .foregroundStyle(password.count >= 8 ? .green : .secondary)
      Text("Минимум 8 символов")
        .font(.caption)
        .foregroundStyle(.secondary)
    }
  }

  private func submit() {
    guard canSubmit, !auth.isWorking else { return }
    focused = nil
    Task {
      _ = await auth.register(displayName: name, email: email, password: password)
    }
  }
}
