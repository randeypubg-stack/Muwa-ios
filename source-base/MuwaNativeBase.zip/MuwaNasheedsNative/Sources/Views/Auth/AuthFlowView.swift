import SwiftUI

struct AuthFlowView: View {
  @EnvironmentObject private var auth: AuthManager
  @State private var mode: AuthMode = .welcome

  var body: some View {
    GeometryReader { proxy in
      let layout = AdaptiveLayout(size: proxy.size, safeArea: proxy.safeAreaInsets)

      ZStack {
        AuthBackground()
          .ignoresSafeArea()

        ScrollView(showsIndicators: false) {
          Group {
            if layout.authUsesSplitLayout {
              HStack(spacing: layout.isCompactLandscapePhone ? 18 : 42) {
                AuthBrandPanel(compact: layout.isCompactLandscapePhone)
                  .frame(maxWidth: layout.isCompactLandscapePhone ? 280 : 440)

                authContent
                  .frame(maxWidth: layout.authFormMaxWidth)
              }
              .frame(maxWidth: layout.contentMaxWidth)
              .padding(.vertical, layout.isCompactLandscapePhone ? 12 : 34)
            } else {
              VStack(spacing: 30) {
                AuthBrandPanel(compact: false)
                  .frame(maxWidth: 440)
                authContent
                  .frame(maxWidth: layout.authFormMaxWidth)
              }
              .frame(maxWidth: min(layout.contentMaxWidth, 620))
              .padding(.vertical, 36)
            }
          }
          .padding(.horizontal, layout.horizontalPadding)
          .frame(maxWidth: .infinity, minHeight: proxy.size.height)
        }
        .scrollDismissesKeyboard(.interactively)
      }
    }
    .animation(.snappy(duration: 0.28), value: mode)
  }

  @ViewBuilder
  private var authContent: some View {
    switch mode {
    case .welcome:
      AuthWelcomeCard(
        signIn: { mode = .login },
        register: { mode = .register },
        guest: auth.continueAsGuest
      )
      .transition(.opacity.combined(with: .scale(scale: 0.985)))
    case .login:
      LoginView(back: { mode = .welcome }, register: { mode = .register })
        .transition(.opacity.combined(with: .move(edge: .trailing)))
    case .register:
      RegisterView(back: { mode = .welcome }, signIn: { mode = .login })
        .transition(.opacity.combined(with: .move(edge: .trailing)))
    }
  }
}

private enum AuthMode {
  case welcome, login, register
}

private struct AuthBrandPanel: View {
  let compact: Bool

  var body: some View {
    VStack(alignment: compact ? .leading : .center, spacing: compact ? 10 : 18) {
      Image("AppMark")
        .resizable()
        .scaledToFit()
        .frame(width: compact ? 74 : 112, height: compact ? 74 : 112)
        .clipShape(RoundedRectangle(cornerRadius: compact ? 20 : 30, style: .continuous))
        .shadow(color: Color.blue.opacity(0.22), radius: 28, y: 12)

      VStack(alignment: compact ? .leading : .center, spacing: 7) {
        Text("Нашиды без музыки")
          .font(.system(size: compact ? 25 : 34, weight: .bold, design: .rounded))
          .foregroundStyle(.white)

        Text("Слушайте нашиды, которые приближают к Аллаху")
          .font(.system(size: compact ? 12 : 15, weight: .medium))
          .foregroundStyle(.white.opacity(0.66))
          .multilineTextAlignment(compact ? .leading : .center)
          .fixedSize(horizontal: false, vertical: true)
      }

      if !compact {
        HStack(spacing: 18) {
          AuthFeature(icon: "headphones", text: "Фоновое\nпрослушивание")
          AuthFeature(icon: "captions.bubble", text: "Тексты и\nпереводы")
          AuthFeature(icon: "arrow.down.circle", text: "Офлайн-\nдоступ")
        }
        .padding(.top, 8)
      }
    }
    .frame(maxWidth: .infinity, alignment: compact ? .leading : .center)
  }
}

private struct AuthFeature: View {
  let icon: String
  let text: String

  var body: some View {
    VStack(spacing: 7) {
      Image(systemName: icon)
        .font(.system(size: 18, weight: .semibold))
        .foregroundStyle(.white.opacity(0.88))
      Text(text)
        .font(.caption2)
        .foregroundStyle(.white.opacity(0.52))
        .multilineTextAlignment(.center)
    }
    .frame(maxWidth: 88)
  }
}

private struct AuthWelcomeCard: View {
  let signIn: () -> Void
  let register: () -> Void
  let guest: () -> Void

  var body: some View {
    VStack(alignment: .leading, spacing: 19) {
      VStack(alignment: .leading, spacing: 7) {
        Text("Добро пожаловать")
          .font(.system(size: 28, weight: .bold, design: .rounded))
        Text("Сохраняйте любимые нашиды и возвращайтесь к ним снова.")
          .font(.subheadline)
          .foregroundStyle(.secondary)
          .fixedSize(horizontal: false, vertical: true)
      }

      Button(action: register) {
        Text("Создать аккаунт")
          .font(.headline)
          .foregroundStyle(.black)
          .frame(maxWidth: .infinity)
          .frame(height: 54)
          .background(.white, in: RoundedRectangle(cornerRadius: 18, style: .continuous))
      }
      .buttonStyle(.plain)

      Button(action: signIn) {
        Text("Войти")
          .font(.headline)
          .frame(maxWidth: .infinity)
          .frame(height: 54)
          .background(
            .white.opacity(0.07), in: RoundedRectangle(cornerRadius: 18, style: .continuous)
          )
          .overlay(
            RoundedRectangle(cornerRadius: 18, style: .continuous).stroke(.white.opacity(0.10)))
      }
      .buttonStyle(.plain)

      Button(action: guest) {
        Text("Продолжить без аккаунта")
          .font(.subheadline.weight(.semibold))
          .foregroundStyle(.white.opacity(0.60))
          .frame(maxWidth: .infinity)
          .padding(.top, 2)
      }
      .buttonStyle(.plain)

      Text("Аккаунт нужен для профиля и публикаций. Прослушивание доступно и без регистрации.")
        .font(.caption2)
        .foregroundStyle(.tertiary)
        .multilineTextAlignment(.center)
        .frame(maxWidth: .infinity)
    }
    .padding(22)
    .authCard()
  }
}

private struct AuthBackground: View {
  var body: some View {
    ZStack {
      LinearGradient(
        colors: [
          Color(red: 0.035, green: 0.075, blue: 0.125),
          Color(red: 0.012, green: 0.028, blue: 0.050),
          Color(red: 0.004, green: 0.008, blue: 0.015),
        ],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
      )
      RadialGradient(
        colors: [Color(red: 0.22, green: 0.45, blue: 0.88).opacity(0.25), .clear],
        center: .topLeading,
        startRadius: 0,
        endRadius: 440
      )
      RadialGradient(
        colors: [Color(red: 0.20, green: 0.64, blue: 0.68).opacity(0.10), .clear],
        center: .bottomTrailing,
        startRadius: 0,
        endRadius: 380
      )

      GeometryReader { proxy in
        ZStack(alignment: .bottom) {
          AuthMountainShape(peaks: [
            0.00, 0.58, 0.17, 0.76, 0.42, 0.68, 0.28, 0.82, 0.46, 0.63, 0.08,
          ])
          .fill(Color(red: 0.08, green: 0.14, blue: 0.19).opacity(0.44))
          .frame(height: proxy.size.height * 0.31)
          AuthMountainShape(peaks: [
            0.12, 0.48, 0.25, 0.61, 0.31, 0.55, 0.20, 0.66, 0.36, 0.51, 0.14,
          ])
          .fill(Color.black.opacity(0.26))
          .frame(height: proxy.size.height * 0.22)
        }
        .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .bottom)
      }
      .allowsHitTesting(false)
    }
  }
}

private struct AuthMountainShape: Shape {
  let peaks: [CGFloat]

  func path(in rect: CGRect) -> Path {
    var path = Path()
    guard peaks.count > 1 else { return path }
    path.move(to: CGPoint(x: 0, y: rect.maxY))
    for (index, peak) in peaks.enumerated() {
      let x = rect.width * CGFloat(index) / CGFloat(peaks.count - 1)
      let y = rect.height * (1 - peak)
      path.addLine(to: CGPoint(x: x, y: y))
    }
    path.addLine(to: CGPoint(x: rect.maxX, y: rect.maxY))
    path.closeSubpath()
    return path
  }
}
