import SwiftUI

struct LoginView: View {
  @EnvironmentObject private var auth: AuthManager
  @FocusState private var focused: Field?

  let back: () -> Void
  let register: () -> Void

  @State private var email = ""
  @State private var password = ""
  @State private var revealPassword = false

  private enum Field { case email, password }

  var body: some View {
    VStack(alignment: .leading, spacing: 18) {
      authHeader(
        title: "Добро пожаловать обратно", subtitle: "Войдите в свой аккаунт, чтобы продолжить",
        back: back)

      VStack(spacing: 12) {
        AuthField(
          title: "Email",
          icon: "envelope",
          text: $email,
          contentType: .emailAddress,
          keyboard: .emailAddress
        )
        .focused($focused, equals: .email)
        .submitLabel(.next)
        .onSubmit { focused = .password }

        AuthSecureField(
          title: "Пароль",
          icon: "lock",
          text: $password,
          revealed: $revealPassword
        )
        .focused($focused, equals: .password)
        .submitLabel(.go)
        .onSubmit { submit() }
      }

      if let error = auth.errorMessage {
        AuthErrorMessage(text: error)
      }

      Button(action: submit) {
        HStack(spacing: 9) {
          if auth.isWorking { ProgressView().tint(.black) }
          Text(auth.isWorking ? "Входим…" : "Войти")
        }
        .font(.headline)
        .foregroundStyle(.black)
        .frame(maxWidth: .infinity)
        .frame(height: 54)
        .background(
          canSubmit ? .white : .white.opacity(0.45),
          in: RoundedRectangle(cornerRadius: 18, style: .continuous))
      }
      .buttonStyle(.plain)
      .disabled(!canSubmit || auth.isWorking)

      Button(action: register) {
        HStack(spacing: 4) {
          Text("Нет аккаунта?")
            .foregroundStyle(.secondary)
          Text("Зарегистрироваться")
            .fontWeight(.semibold)
        }
        .font(.subheadline)
        .frame(maxWidth: .infinity)
      }
      .buttonStyle(.plain)
    }
    .padding(22)
    .authCard()
    .onAppear { auth.errorMessage = nil }
  }

  private var canSubmit: Bool {
    isValidEmail(email) && !password.isEmpty
  }

  private func isValidEmail(_ value: String) -> Bool {
    let trimmed = value.trimmingCharacters(in: .whitespacesAndNewlines)
    return trimmed.range(
      of: #"^[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}$"#,
      options: [.regularExpression, .caseInsensitive]
    ) != nil
  }

  private func submit() {
    guard canSubmit, !auth.isWorking else { return }
    focused = nil
    Task { _ = await auth.login(email: email, password: password) }
  }
}
