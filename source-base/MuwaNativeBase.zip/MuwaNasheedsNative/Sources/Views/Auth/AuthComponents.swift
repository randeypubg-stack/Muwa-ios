import SwiftUI
import UIKit

@ViewBuilder
func authHeader(title: String, subtitle: String, back: @escaping () -> Void) -> some View {
  VStack(alignment: .leading, spacing: 14) {
    Button(action: back) {
      HStack(spacing: 6) {
        Image(systemName: "chevron.left")
        Text("Назад")
      }
      .font(.subheadline.weight(.semibold))
      .foregroundStyle(.white.opacity(0.68))
    }
    .buttonStyle(.plain)

    VStack(alignment: .leading, spacing: 5) {
      Text(title)
        .font(.system(size: 28, weight: .bold, design: .rounded))
      Text(subtitle)
        .font(.subheadline)
        .foregroundStyle(.secondary)
    }
  }
}

struct AuthField: View {
  let title: String
  let icon: String
  @Binding var text: String
  let contentType: UITextContentType?
  let keyboard: UIKeyboardType
  var capitalization: TextInputAutocapitalization = .never

  var body: some View {
    HStack(spacing: 11) {
      Image(systemName: icon)
        .foregroundStyle(.white.opacity(0.55))
        .frame(width: 20)
      TextField(title, text: $text)
        .textContentType(contentType)
        .keyboardType(keyboard)
        .textInputAutocapitalization(capitalization)
        .autocorrectionDisabled()
        .font(.body)
    }
    .padding(.horizontal, 15)
    .frame(height: 54)
    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(.white.opacity(0.07)))
  }
}

struct AuthSecureField: View {
  let title: String
  let icon: String
  @Binding var text: String
  @Binding var revealed: Bool

  var body: some View {
    HStack(spacing: 11) {
      Image(systemName: icon)
        .foregroundStyle(.white.opacity(0.55))
        .frame(width: 20)

      Group {
        if revealed {
          TextField(title, text: $text)
        } else {
          SecureField(title, text: $text)
        }
      }
      .textContentType(.password)
      .textInputAutocapitalization(.never)
      .autocorrectionDisabled()
      .font(.body)

      Button {
        revealed.toggle()
      } label: {
        Image(systemName: revealed ? "eye.slash" : "eye")
          .foregroundStyle(.white.opacity(0.48))
          .frame(width: 30, height: 34)
      }
      .buttonStyle(.plain)
    }
    .padding(.horizontal, 15)
    .frame(height: 54)
    .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 17, style: .continuous))
    .overlay(RoundedRectangle(cornerRadius: 17, style: .continuous).stroke(.white.opacity(0.07)))
  }
}

struct AuthErrorMessage: View {
  let text: String

  var body: some View {
    HStack(alignment: .top, spacing: 9) {
      Image(systemName: "exclamationmark.circle.fill")
        .foregroundStyle(.red.opacity(0.88))
      Text(text)
        .font(.caption)
        .foregroundStyle(.white.opacity(0.76))
        .fixedSize(horizontal: false, vertical: true)
      Spacer(minLength: 0)
    }
    .padding(12)
    .background(.red.opacity(0.075), in: RoundedRectangle(cornerRadius: 15, style: .continuous))
  }
}

extension View {
  func authCard() -> some View {
    self
      .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
      .overlay(
        RoundedRectangle(cornerRadius: 30, style: .continuous)
          .stroke(.white.opacity(0.10), lineWidth: 1)
      )
      .shadow(color: .black.opacity(0.20), radius: 30, y: 18)
  }
}
