import SwiftUI

struct RegistrationSuccessView: View {
  @EnvironmentObject private var auth: AuthManager

  var body: some View {
    GeometryReader { proxy in
      let layout = AdaptiveLayout(size: proxy.size, safeArea: proxy.safeAreaInsets)

      ZStack {
        AuthSuccessBackground().ignoresSafeArea()

        VStack(spacing: layout.isCompactLandscapePhone ? 14 : 24) {
          ZStack {
            Circle()
              .fill(Color.green.opacity(0.14))
              .frame(
                width: layout.isCompactLandscapePhone ? 74 : 104,
                height: layout.isCompactLandscapePhone ? 74 : 104)
            Circle()
              .stroke(Color.green.opacity(0.52), lineWidth: 1.5)
              .frame(
                width: layout.isCompactLandscapePhone ? 74 : 104,
                height: layout.isCompactLandscapePhone ? 74 : 104)
            Image(systemName: "checkmark")
              .font(.system(size: layout.isCompactLandscapePhone ? 30 : 42, weight: .semibold))
              .foregroundStyle(.white)
          }

          VStack(spacing: 10) {
            Text("Добро пожаловать!")
              .font(
                .system(
                  size: layout.isCompactLandscapePhone ? 25 : 32, weight: .bold, design: .rounded))

            Text(
              "Ваш аккаунт успешно создан. Теперь вы можете слушать нашиды, сохранять избранное и пользоваться всеми возможностями Muwa."
            )
            .font(.system(size: layout.isCompactLandscapePhone ? 13 : 15, weight: .regular))
            .foregroundStyle(.white.opacity(0.66))
            .multilineTextAlignment(.center)
            .fixedSize(horizontal: false, vertical: true)
          }

          Button {
            auth.finishRegistrationConfirmation()
          } label: {
            Text("Перейти в приложение")
              .font(.headline)
              .foregroundStyle(.black)
              .frame(maxWidth: .infinity)
              .frame(height: 56)
              .background(.white, in: Capsule())
          }
          .buttonStyle(.plain)
          .frame(maxWidth: 420)
        }
        .padding(.horizontal, layout.horizontalPadding)
        .frame(maxWidth: layout.authFormMaxWidth + 80)
        .frame(maxWidth: .infinity, maxHeight: .infinity)
      }
    }
  }
}

private struct AuthSuccessBackground: View {
  var body: some View {
    ZStack {
      LinearGradient(
        colors: [Color(red: 0.015, green: 0.065, blue: 0.07), Color.black],
        startPoint: .topLeading,
        endPoint: .bottomTrailing
      )
      RadialGradient(
        colors: [Color.green.opacity(0.16), .clear],
        center: .center,
        startRadius: 0,
        endRadius: 360
      )
    }
  }
}
