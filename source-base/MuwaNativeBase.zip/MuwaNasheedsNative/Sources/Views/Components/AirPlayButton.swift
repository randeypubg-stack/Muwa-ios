import AVKit
import SwiftUI

struct AirPlayButton: UIViewRepresentable {
  func makeUIView(context: Context) -> AVRoutePickerView {
    let picker = AVRoutePickerView()
    picker.prioritizesVideoDevices = false
    picker.tintColor = .white
    picker.activeTintColor = .white
    return picker
  }

  func updateUIView(_ uiView: AVRoutePickerView, context: Context) {}
}
