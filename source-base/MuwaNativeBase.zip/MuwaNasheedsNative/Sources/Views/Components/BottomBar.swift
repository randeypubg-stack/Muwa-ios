import SwiftUI

struct BottomBar: View {
  @Binding var selection: AppTab
  var playerActive = false
  let openPlayer: () -> Void
  var selectTab: ((AppTab) -> Void)? = nil

  @Namespace private var highlight

  var body: some View {
    HStack(spacing: 2) {
      item(.home, "Главная", "house.fill")
      playerItem
      item(.library, "Библиотека", "books.vertical.fill")
      item(.profile, "Профиль", "person.fill")
    }
    .frame(height: 58)
    .padding(5)
    .background(.ultraThinMaterial, in: RoundedRectangle(cornerRadius: 30, style: .continuous))
    .overlay(
      RoundedRectangle(cornerRadius: 30, style: .continuous)
        .stroke(.white.opacity(0.14), lineWidth: 1)
    )
    .shadow(color: .black.opacity(0.16), radius: 24, y: 10)
  }

  private var playerItem: some View {
    Button(action: openPlayer) {
      tabLabel("Плеер", "play.fill", active: playerActive)
    }
    .buttonStyle(.plain)
    .frame(maxWidth: .infinity)
  }

  private func item(_ tab: AppTab, _ title: String, _ systemImage: String) -> some View {
    let active = !playerActive && selection == tab
    return Button {
      if let selectTab { selectTab(tab) } else { selection = tab }
    } label: {
      tabLabel(title, systemImage, active: active)
    }
    .buttonStyle(.plain)
    .frame(maxWidth: .infinity)
  }

  private func tabLabel(_ title: String, _ systemImage: String, active: Bool) -> some View {
    VStack(spacing: 3) {
      Image(systemName: systemImage)
        .font(.system(size: 17, weight: .semibold))
      Text(title)
        .font(.system(size: 9, weight: .medium))
    }
    .foregroundStyle(active ? .white : .white.opacity(0.66))
    .frame(maxWidth: .infinity, maxHeight: .infinity)
    .background {
      if active {
        RoundedRectangle(cornerRadius: 23, style: .continuous)
          .fill(
            LinearGradient(
              colors: [.white.opacity(0.12), .white.opacity(0.045)],
              startPoint: .topLeading,
              endPoint: .bottomTrailing
            )
          )
          .overlay(
            RoundedRectangle(cornerRadius: 23, style: .continuous)
              .stroke(.white.opacity(0.12), lineWidth: 1)
          )
          .matchedGeometryEffect(id: "active-tab", in: highlight)
      }
    }
    .contentShape(Rectangle())
    .animation(.snappy(duration: 0.32), value: active)
  }
}
