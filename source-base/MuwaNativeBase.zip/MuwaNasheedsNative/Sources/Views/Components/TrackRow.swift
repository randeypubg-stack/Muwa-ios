import SwiftUI

struct TrackRow: View {
  let track: Track
  var isPlaying = false
  var trailingSystemImage: String? = nil
  var action: () -> Void
  var trailingAction: (() -> Void)? = nil

  var body: some View {
    HStack(spacing: 11) {
      Button(action: action) {
        HStack(spacing: 11) {
          ArtworkView(url: track.artworkURL, cornerRadius: 13, placeholderSystemImage: "music.note")
            .frame(width: 44, height: 44)
          VStack(alignment: .leading, spacing: 3) {
            Text(track.title)
              .font(.system(size: 14, weight: .semibold))
              .lineLimit(1)
            HStack(spacing: 6) {
              Text(track.artist)
              Text("•")
              Text(track.durationText)
            }
            .font(.system(size: 10))
            .foregroundStyle(.secondary)
          }
          Spacer(minLength: 6)
          if isPlaying {
            Image(systemName: "waveform")
              .symbolEffect(.variableColor.iterative, options: .repeating)
              .foregroundStyle(.yellow)
          }
        }
      }
      .buttonStyle(.plain)

      if let trailingSystemImage, let trailingAction {
        Button(action: trailingAction) {
          Image(systemName: trailingSystemImage)
            .font(.system(size: 15, weight: .semibold))
            .frame(width: 36, height: 36)
        }
        .buttonStyle(.plain)
        .foregroundStyle(.secondary)
      }
    }
    .padding(.vertical, 5)
    .contentShape(Rectangle())
  }
}
