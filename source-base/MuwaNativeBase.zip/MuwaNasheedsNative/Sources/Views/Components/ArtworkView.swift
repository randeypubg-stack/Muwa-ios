import SwiftUI

struct ArtworkView: View {
  let url: URL?
  var cornerRadius: CGFloat = 24
  var placeholderSystemImage = "waveform"

  var body: some View {
    ZStack {
      RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        .fill(Color.white.opacity(0.055))

      if let url {
        AsyncImage(url: url, transaction: Transaction(animation: .easeOut(duration: 0.2))) {
          phase in
          switch phase {
          case .success(let image):
            image
              .resizable()
              .scaledToFit()
              .frame(maxWidth: .infinity, maxHeight: .infinity)
          case .failure:
            placeholder
          case .empty:
            ProgressView().tint(.white.opacity(0.75))
          @unknown default:
            placeholder
          }
        }
      } else {
        placeholder
      }
    }
    .clipShape(RoundedRectangle(cornerRadius: cornerRadius, style: .continuous))
    .overlay(
      RoundedRectangle(cornerRadius: cornerRadius, style: .continuous)
        .stroke(.white.opacity(0.07), lineWidth: 1)
    )
  }

  private var placeholder: some View {
    Image(systemName: placeholderSystemImage)
      .font(.system(size: 34, weight: .medium))
      .foregroundStyle(.white.opacity(0.78))
  }
}

struct ArtworkBackdrop: View {
  let url: URL?

  var body: some View {
    ZStack {
      AppBackground()
      if let url {
        AsyncImage(url: url) { phase in
          if case .success(let image) = phase {
            image
              .resizable()
              .scaledToFill()
              .blur(radius: 44)
              .saturation(1.18)
              .opacity(0.54)
              .scaleEffect(1.22)
          }
        }
      }
      LinearGradient(
        colors: [.black.opacity(0.08), .black.opacity(0.50), .black.opacity(0.90)],
        startPoint: .top,
        endPoint: .bottom
      )
    }
    .clipped()
  }
}
