import SwiftUI

struct SubtitlePanel: View {
  @EnvironmentObject private var subtitles: SubtitleManager
  let track: Track
  let currentTime: TimeInterval
  @Binding var language: SubtitleLanguage

  private var segments: [SubtitleSegment] { subtitles.segments(for: track) }
  private var activeIndex: Int? { subtitles.activeIndex(for: track, time: currentTime) }

  var body: some View {
    VStack(spacing: 11) {
      HStack(spacing: 12) {
        Text("Субтитры")
          .font(.subheadline.bold())
        Spacer()
        Picker("Язык", selection: $language) {
          ForEach(SubtitleLanguage.allCases) { item in
            Text(item.rawValue).tag(item)
          }
        }
        .pickerStyle(.segmented)
        .frame(maxWidth: 190)
      }

      content
        .frame(maxWidth: .infinity, minHeight: 88, alignment: .center)
    }
    .padding(14)
    .background(.black.opacity(0.20), in: RoundedRectangle(cornerRadius: 20, style: .continuous))
    .overlay(
      RoundedRectangle(cornerRadius: 20, style: .continuous)
        .stroke(.white.opacity(0.055), lineWidth: 1)
    )
    .task(id: track.id) { subtitles.load(for: track) }
  }

  @ViewBuilder
  private var content: some View {
    switch subtitles.state(for: track) {
    case .idle, .loading:
      VStack(spacing: 9) {
        ProgressView().tint(.white)
        Text("Синхронизируем текст с аудио…")
          .font(.caption)
          .foregroundStyle(.secondary)
      }
    case .unavailable(let message):
      VStack(spacing: 7) {
        Image(systemName: "captions.bubble")
          .foregroundStyle(.secondary)
        Text(message)
          .font(.caption)
          .foregroundStyle(.secondary)
          .multilineTextAlignment(.center)
          .lineSpacing(2)
      }
    case .ready:
      if let activeIndex, segments.indices.contains(activeIndex) {
        let previous = activeIndex > 0 ? segments[activeIndex - 1] : nil
        let active = segments[activeIndex]
        let next = activeIndex + 1 < segments.count ? segments[activeIndex + 1] : nil

        VStack(spacing: 7) {
          if let previous {
            Text(previous.text(for: language))
              .font(.caption)
              .foregroundStyle(.white.opacity(0.30))
              .lineLimit(1)
          }

          if language == .arabic {
            highlightedArabic(active)
              .font(.system(size: 22, weight: .semibold))
              .multilineTextAlignment(.center)
              .environment(\.layoutDirection, .rightToLeft)
          } else {
            Text(active.text(for: language))
              .font(.system(size: 17, weight: .semibold))
              .multilineTextAlignment(.center)
              .foregroundStyle(.white)
            Text(active.ar)
              .font(.system(size: 14))
              .multilineTextAlignment(.center)
              .foregroundStyle(.white.opacity(0.58))
              .environment(\.layoutDirection, .rightToLeft)
          }

          if let next {
            Text(next.text(for: language))
              .font(.caption)
              .foregroundStyle(.white.opacity(0.48))
              .lineLimit(1)
          }
        }
        .animation(.easeInOut(duration: 0.18), value: activeIndex)
      } else {
        Text("Текст начнётся вместе с вокалом")
          .font(.caption)
          .foregroundStyle(.secondary)
      }
    }
  }

  private func highlightedArabic(_ segment: SubtitleSegment) -> Text {
    guard let words = segment.words, !words.isEmpty else { return Text(segment.ar) }
    return words.enumerated().reduce(Text("")) { partial, item in
      let (index, word) = item
      let active = currentTime >= word.start && currentTime < word.end
      let prefix = index == 0 ? "" : " "
      return partial
        + Text(prefix + word.text)
        .foregroundColor(active ? Color(red: 1.0, green: 0.84, blue: 0.35) : .white)
    }
  }
}
