import SwiftUI

struct PlayerSubtitleOverlay: View {
  @EnvironmentObject private var subtitles: SubtitleManager
  let track: Track
  let currentTime: TimeInterval
  let language: SubtitleLanguage

  private var segments: [SubtitleSegment] { subtitles.segments(for: track) }
  private var activeIndex: Int? { subtitles.activeIndex(for: track, time: currentTime) }

  var body: some View {
    Group {
      if let activeIndex, segments.indices.contains(activeIndex) {
        let current = segments[activeIndex]
        let previous = activeIndex > 0 ? segments[activeIndex - 1] : nil
        let next = activeIndex + 1 < segments.count ? segments[activeIndex + 1] : nil

        VStack(alignment: .trailing, spacing: 7) {
          if let previous {
            Text(previous.ar)
              .font(.system(size: 12))
              .foregroundStyle(.white.opacity(0.28))
              .lineLimit(1)
          }

          Text(current.ar)
            .font(.system(size: 20, weight: .semibold))
            .multilineTextAlignment(.trailing)
            .foregroundStyle(.white)
            .lineLimit(2)
            .environment(\.layoutDirection, .rightToLeft)

          if language != .arabic {
            Text(current.text(for: language))
              .font(.system(size: 10, weight: .medium))
              .foregroundStyle(.white.opacity(0.78))
              .multilineTextAlignment(.trailing)
              .lineLimit(2)
          }

          if let next {
            Text(next.ar)
              .font(.system(size: 12))
              .foregroundStyle(.white.opacity(0.43))
              .lineLimit(1)
          }
        }
        .padding(.vertical, 12)
        .padding(.horizontal, 13)
        .frame(maxWidth: 196, alignment: .trailing)
        .background(
          LinearGradient(
            colors: [.black.opacity(0.05), .black.opacity(0.38)],
            startPoint: .leading,
            endPoint: .trailing
          ),
          in: RoundedRectangle(cornerRadius: 20, style: .continuous)
        )
        .background(
          .ultraThinMaterial.opacity(0.34),
          in: RoundedRectangle(cornerRadius: 20, style: .continuous)
        )
        .transition(.opacity.combined(with: .move(edge: .trailing)))
      }
    }
    .allowsHitTesting(false)
    .animation(.easeInOut(duration: 0.18), value: activeIndex)
  }
}
