import SwiftUI

struct QueueView: View {
  @Environment(\.dismiss) private var dismiss
  @EnvironmentObject private var player: PlayerManager
  @EnvironmentObject private var library: LibraryStore

  var body: some View {
    NavigationStack {
      List {
        ForEach(library.queueTracks) { track in
          Button {
            player.play(track)
            dismiss()
          } label: {
            HStack(spacing: 10) {
              ArtworkView(
                url: track.artworkURL, cornerRadius: 10, placeholderSystemImage: "music.note"
              )
              .frame(width: 40, height: 40)
              VStack(alignment: .leading, spacing: 3) {
                Text(track.title).font(.subheadline.bold()).lineLimit(1)
                Text(track.artist).font(.caption).foregroundStyle(.secondary).lineLimit(1)
              }
              Spacer()
              if player.currentTrack?.id == track.id {
                Image(systemName: "waveform")
                  .foregroundStyle(.yellow)
              } else {
                Text(track.durationText).font(.caption2).foregroundStyle(.secondary)
              }
            }
          }
          .buttonStyle(.plain)
          .listRowBackground(Color.clear)
        }
        .onMove(perform: library.moveQueue)
      }
      .scrollContentBackground(.hidden)
      .background(AppBackground())
      .environment(\.editMode, .constant(.active))
      .navigationTitle("Очередь")
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        ToolbarItem(placement: .topBarTrailing) {
          Button("Готово") { dismiss() }
        }
      }
    }
    .presentationDetents([.medium, .large])
    .presentationDragIndicator(.visible)
  }
}
