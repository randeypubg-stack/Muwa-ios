import SwiftUI
import UniformTypeIdentifiers

struct PublicationFlowView: View {
  @Environment(\.dismiss) private var dismiss
  @EnvironmentObject private var library: LibraryStore
  @EnvironmentObject private var auth: AuthManager

  @State private var step: Step = .audio
  @State private var draftID = UUID()
  @State private var audioName = ""
  @State private var coverName = ""
  @State private var audioURL: URL?
  @State private var coverURL: URL?
  @State private var title = ""
  @State private var artist = ""
  @State private var language = "Арабский"
  @State private var audioImporterPresented = false
  @State private var coverImporterPresented = false
  @State private var sent = false
  @State private var submitting = false
  @State private var submitError: String?

  enum Step: Int, CaseIterable {
    case audio, details, preview
  }

  var body: some View {
    GeometryReader { proxy in
      let layout = AdaptiveLayout(size: proxy.size, safeArea: proxy.safeAreaInsets)

      ZStack {
        AppBackground().ignoresSafeArea()
        VStack(spacing: 0) {
          topBar
            .adaptiveFrame(maxWidth: min(layout.contentMaxWidth, 900))
          progress
            .adaptiveFrame(maxWidth: min(layout.contentMaxWidth, 900))

          ScrollView(showsIndicators: false) {
            content(layout: layout)
              .padding(.horizontal, layout.horizontalPadding)
              .padding(.top, layout.isCompactLandscapePhone ? 12 : 28)
              .padding(.bottom, 24)
              .adaptiveFrame(maxWidth: min(layout.contentMaxWidth, 900))
          }

          footer
            .padding(.horizontal, layout.horizontalPadding)
            .adaptiveFrame(maxWidth: min(layout.contentMaxWidth, 900))
        }
      }
    }
    .fileImporter(
      isPresented: $audioImporterPresented,
      allowedContentTypes: [.audio],
      allowsMultipleSelection: false
    ) { result in
      if case .success(let urls) = result, let url = urls.first {
        audioURL = url
        audioName = url.lastPathComponent
      }
    }
    .fileImporter(
      isPresented: $coverImporterPresented,
      allowedContentTypes: [.image],
      allowsMultipleSelection: false
    ) { result in
      if case .success(let urls) = result, let url = urls.first {
        coverURL = url
        coverName = url.lastPathComponent
      }
    }
    .alert(
      "Не удалось отправить публикацию",
      isPresented: Binding(
        get: { submitError != nil },
        set: { if !$0 { submitError = nil } }
      )
    ) {
      Button("OK", role: .cancel) {}
    } message: {
      Text(submitError ?? "Неизвестная ошибка")
    }
  }

  private var topBar: some View {
    HStack {
      Button(action: { dismiss() }) {
        Image(systemName: "xmark")
          .frame(width: 40, height: 40)
          .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 15))
      }
      .buttonStyle(.plain)
      Spacer()
      VStack(spacing: 2) {
        Text(sent ? "Готово" : "Новая публикация").font(.subheadline.bold())
        if !sent {
          Text("Шаг \(step.rawValue + 1) из 3").font(.caption2).foregroundStyle(.secondary)
        }
      }
      Spacer()
      Color.clear.frame(width: 40, height: 40)
    }
    .padding(.horizontal, 20)
    .padding(.top, 8)
  }

  private var progress: some View {
    HStack(spacing: 5) {
      ForEach(Step.allCases, id: \.rawValue) { item in
        Capsule()
          .fill(item.rawValue <= step.rawValue ? .white.opacity(0.82) : .white.opacity(0.10))
          .frame(height: 2)
      }
    }
    .padding(.horizontal, 25)
    .padding(.top, 10)
    .opacity(sent ? 0 : 1)
  }

  @ViewBuilder
  private func content(layout: AdaptiveLayout) -> some View {
    if sent {
      VStack(spacing: 14) {
        Image(systemName: "checkmark")
          .font(.system(size: 30, weight: .bold))
          .frame(width: 72, height: 72)
          .background(.green.opacity(0.12), in: Circle())
          .foregroundStyle(.green)
        Text("Отправлено на модерацию")
          .font(.title2.bold())
        Text(
          "Аудио, обложка и карточка публикации загружены в закрытую серверную очередь. До одобрения материал не показывается слушателям."
        )
        .font(.subheadline)
        .foregroundStyle(.secondary)
        .multilineTextAlignment(.center)
        .lineSpacing(2)
        .frame(maxWidth: 520)
        Button("Вернуться в библиотеку") { dismiss() }
          .buttonStyle(.bordered)
          .padding(.top, 8)
      }
      .frame(maxWidth: .infinity)
      .padding(.top, layout.isLandscape ? 28 : 70)
    } else {
      switch step {
      case .audio: audioStep
      case .details: detailsStep(layout: layout)
      case .preview: previewStep(layout: layout)
      }
    }
  }

  private var audioStep: some View {
    VStack(spacing: 24) {
      Image(systemName: "waveform.badge.plus")
        .font(.system(size: 46, weight: .medium))
        .foregroundStyle(.white.opacity(0.88))
      VStack(spacing: 7) {
        Text("Выберите аудиофайл").font(.title2.bold())
        Text("MP3, M4A или другой аудиоформат, поддерживаемый iOS.")
          .font(.subheadline)
          .foregroundStyle(.secondary)
          .multilineTextAlignment(.center)
      }
      pickerRow(
        icon: "waveform",
        title: audioName.isEmpty ? "Выбрать аудио" : audioName,
        subtitle: audioName.isEmpty ? "Файл будет загружен только после отправки" : "Аудио выбрано",
        action: { audioImporterPresented = true }
      )
    }
    .padding(.top, 28)
  }

  private func detailsStep(layout: AdaptiveLayout) -> some View {
    Group {
      if layout.isWide {
        HStack(alignment: .top, spacing: 22) {
          VStack(alignment: .leading, spacing: 18) {
            field("Название нашида", text: $title)
            field("Автор / исполнитель", text: $artist)
          }
          VStack(alignment: .leading, spacing: 18) {
            languagePicker
            coverPicker
          }
        }
      } else {
        VStack(alignment: .leading, spacing: 18) {
          field("Название нашида", text: $title)
          field("Автор / исполнитель", text: $artist)
          languagePicker
          coverPicker
        }
      }
    }
    .overlay(alignment: .bottomLeading) {
      Button("Сохранить как черновик") {
        save(status: .draft)
        dismiss()
      }
      .buttonStyle(.bordered)
      .offset(y: 62)
    }
    .padding(.bottom, 62)
  }

  private var languagePicker: some View {
    VStack(alignment: .leading, spacing: 8) {
      Text("Язык").font(.caption).foregroundStyle(.secondary)
      Picker("Язык", selection: $language) {
        Text("Арабский").tag("Арабский")
        Text("Русский").tag("Русский")
        Text("Другой").tag("Другой")
      }
      .pickerStyle(.segmented)
    }
  }

  private var coverPicker: some View {
    pickerRow(
      icon: "photo",
      title: coverName.isEmpty ? "Добавить обложку" : coverName,
      subtitle: "Исходное изображение сохраняется без принудительного кропа",
      action: { coverImporterPresented = true }
    )
  }

  private func previewStep(layout: AdaptiveLayout) -> some View {
    Group {
      if layout.isWide {
        HStack(alignment: .top, spacing: 28) {
          previewCard
          moderationCard.frame(maxWidth: 390)
        }
      } else {
        VStack(alignment: .leading, spacing: 20) {
          previewCard
          moderationCard
        }
      }
    }
  }

  private var previewCard: some View {
    VStack(alignment: .leading, spacing: 14) {
      Text("Предпросмотр").font(.caption).foregroundStyle(.secondary)
      HStack(spacing: 15) {
        RoundedRectangle(cornerRadius: 25)
          .fill(.white.opacity(0.06))
          .frame(width: 92, height: 92)
          .overlay(
            Image(systemName: coverName.isEmpty ? "photo" : "checkmark.circle").font(.title2))
        VStack(alignment: .leading, spacing: 5) {
          Text(title.isEmpty ? "Без названия" : title).font(.title3.bold()).lineLimit(2)
          Text(artist.isEmpty ? "Автор не указан" : artist).foregroundStyle(.secondary)
          Text(audioName).font(.caption2).foregroundStyle(.tertiary).lineLimit(1)
        }
      }
      .padding(.vertical, 8)
    }
    .frame(maxWidth: .infinity, alignment: .leading)
  }

  private var moderationCard: some View {
    HStack(alignment: .top, spacing: 10) {
      Image(systemName: "shield.checkered")
      VStack(alignment: .leading, spacing: 5) {
        Text("Публикация появится только после проверки").font(.subheadline.bold())
        Text(
          "Будут проверены название, автор, обложка, аудио и отсутствие рекламы. Сервер хранит файлы закрыто до решения модератора."
        )
        .font(.caption)
        .foregroundStyle(.secondary)
        .lineSpacing(2)
      }
    }
    .padding(15)
    .nativeCard(cornerRadius: 18)
  }

  private var footer: some View {
    HStack(spacing: 10) {
      if !sent, step != .audio {
        Button("Назад") {
          step = Step(rawValue: step.rawValue - 1) ?? .audio
        }
        .buttonStyle(.bordered)
        .frame(width: 94, height: 52)
        .disabled(submitting)
      }

      if !sent {
        Button {
          if step == .preview {
            submitPublication()
          } else {
            step = Step(rawValue: step.rawValue + 1) ?? .preview
          }
        } label: {
          HStack(spacing: 8) {
            if submitting { ProgressView().tint(.black) }
            Text(
              step == .preview
                ? (submitting ? "Отправляем…" : "Отправить на модерацию") : "Продолжить")
          }
          .frame(maxWidth: .infinity)
        }
        .buttonStyle(.borderedProminent)
        .tint(.white)
        .foregroundStyle(.black)
        .frame(maxWidth: .infinity)
        .frame(height: 52)
        .disabled(!canContinue || submitting)
      }
    }
    .padding(.bottom, 12)
  }

  private var canContinue: Bool {
    switch step {
    case .audio: return audioURL != nil
    case .details: return !title.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    case .preview: return audioURL != nil
    }
  }

  private func submitPublication() {
    guard auth.isAuthenticated else {
      submitError = "Войдите в аккаунт, чтобы отправлять публикации."
      return
    }
    guard let audioURL else { return }
    submitting = true
    submitError = nil
    Task {
      do {
        let receipt = try await PublicationUploadService.shared.submit(
          id: draftID,
          title: title,
          artist: artist,
          language: language,
          audioURL: audioURL,
          coverURL: coverURL
        )
        let draft = PublicationDraft(
          id: draftID,
          title: title,
          artist: artist,
          language: language,
          audioName: audioName,
          coverName: coverName,
          status: .moderation,
          createdAt: .now,
          audioStorageKey: receipt.audioStorageKey,
          coverStorageKey: receipt.coverStorageKey,
          submissionStorageKey: receipt.submissionStorageKey
        )
        library.updatePublication(draft)
        sent = true
      } catch {
        submitError = error.localizedDescription
      }
      submitting = false
    }
  }

  private func save(status: PublicationStatus) {
    library.updatePublication(
      PublicationDraft(
        id: draftID,
        title: title,
        artist: artist,
        language: language,
        audioName: audioName,
        coverName: coverName,
        status: status
      )
    )
  }

  private func pickerRow(
    icon: String,
    title: String,
    subtitle: String,
    action: @escaping () -> Void
  ) -> some View {
    Button(action: action) {
      HStack(spacing: 12) {
        Image(systemName: icon).font(.title3)
        VStack(alignment: .leading, spacing: 4) {
          Text(title).font(.subheadline.bold()).lineLimit(1)
          Text(subtitle).font(.caption2).foregroundStyle(.secondary).lineLimit(2)
        }
        Spacer()
        Image(systemName: "chevron.right").foregroundStyle(.secondary)
      }
      .padding(15)
      .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 20))
    }
    .buttonStyle(.plain)
  }

  private func field(_ label: String, text: Binding<String>) -> some View {
    VStack(alignment: .leading, spacing: 8) {
      Text(label).font(.caption).foregroundStyle(.secondary)
      TextField(label, text: text)
        .padding(.horizontal, 14)
        .frame(height: 50)
        .background(.white.opacity(0.055), in: RoundedRectangle(cornerRadius: 17))
    }
  }
}
