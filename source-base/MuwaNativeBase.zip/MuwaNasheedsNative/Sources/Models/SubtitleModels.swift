import Foundation

enum SubtitleLanguage: String, CaseIterable, Identifiable, Codable, Sendable {
  case arabic = "AR"
  case russian = "RU"
  case english = "EN"
  var id: String { rawValue }
}

struct SubtitleWord: Codable, Hashable, Sendable {
  let text: String
  let start: TimeInterval
  let end: TimeInterval
}

struct SubtitleSegment: Codable, Hashable, Sendable, Identifiable {
  var id: String { "\(start)-\(end)-\(ar)" }
  let start: TimeInterval
  let end: TimeInterval
  let ar: String
  let ru: String
  let en: String
  let words: [SubtitleWord]?

  func text(for language: SubtitleLanguage) -> String {
    switch language {
    case .arabic: return ar
    case .russian: return ru
    case .english: return en
    }
  }
}
