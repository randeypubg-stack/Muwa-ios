import Foundation

struct AuthUser: Codable, Equatable, Sendable {
  let id: Int
  let email: String
  let displayName: String
  let avatarUrl: String?
  let role: String
}
