import Foundation

enum PublicationStatus: String, Codable, CaseIterable, Sendable {
  case draft
  case moderation
  case changes
  case approved
  case rejected

  var title: String {
    switch self {
    case .draft: return "Черновик"
    case .moderation: return "На модерации"
    case .changes: return "Нужны изменения"
    case .approved: return "Одобрено"
    case .rejected: return "Отклонено"
    }
  }
}

struct PublicationDraft: Identifiable, Codable, Hashable, Sendable {
  var id: UUID = UUID()
  var title: String
  var artist: String
  var language: String
  var audioName: String
  var coverName: String
  var status: PublicationStatus
  var createdAt: Date = .now
  var audioStorageKey: String? = nil
  var coverStorageKey: String? = nil
  var submissionStorageKey: String? = nil
}
