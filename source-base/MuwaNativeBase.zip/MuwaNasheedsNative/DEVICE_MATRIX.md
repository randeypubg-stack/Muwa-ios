# Device / orientation QA matrix

The layout is width-driven so iPad Split View and Stage Manager are treated as real window sizes, not as a hard-coded “iPad layout”.

## iPhone
- Portrait compact width: single-column Home/Profile, 2-column Library cards, portrait full player.
- Landscape: wide Home/Library/Profile compositions; full player uses artwork left + controls right; bottom bar remains anchored to bottom.
- Home indicator / safe area: bottom chrome uses safe-area insets through SwiftUI safeAreaInset.

Suggested checks in Xcode:
- iPhone SE (3rd gen) portrait + landscape
- iPhone 15/16 portrait + landscape
- iPhone 15/16 Pro Max portrait + landscape

## iPad
- Narrow Split View: falls back to compact layouts rather than forcing desktop-sized columns.
- Portrait: bounded content width; Library expands to explicit grid when room permits.
- Landscape: large split player and multi-column discovery/library content.
- Stage Manager resizing: geometry recalculates continuously from the active window size.

Suggested checks:
- iPad mini
- 10.9/11-inch iPad / iPad Air / iPad Pro
- 12.9/13-inch iPad Pro / iPad Air
- 1/3 and 1/2 Split View widths
- Stage Manager narrow and wide windows

## Invariants
- Bottom navigation never changes to a floating side rail just because orientation changes.
- Mini-player remains directly above bottom navigation.
- Artwork remains aspect-fit; it is not stretched/cropped to fake a responsive layout.
- Landscape uses explicit two-column/split compositions instead of arbitrary control offsets.
