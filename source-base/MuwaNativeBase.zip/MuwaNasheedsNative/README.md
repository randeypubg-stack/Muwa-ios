# Muwa Nasheeds — native SwiftUI v8 audited

Muwa Nasheeds is a fully native iPhone/iPad application. The UI contains **no WebView, React, HTML, CSS or Capacitor screens**.

## Native stack
- SwiftUI screens, navigation and adaptive layouts
- AVPlayer / AVAudioSession for playback
- MediaPlayer for Now Playing / Lock Screen / Control Center commands
- StoreKit 2 for Premium entitlements and purchases
- URLSession for authentication, media, subtitles and publication uploads
- Native document import for publication audio/covers
- Native AirPlay route picker

## Authentication
Welcome, Login, Registration and registration confirmation are native SwiftUI views. Email/password accounts use the Muwa backend and real database-backed sessions. URLSession keeps the HTTP-only session cookie and restores the session on launch.

Guest listening remains available. Account login is required before starting the publication flow.

Release builds prefer the production API. While a newly changed backend is waiting for its next production publish, selected server-unavailable statuses can fall back to the Floot sandbox API. The auth service remembers which host successfully authenticated the user so session restore remains consistent across launches, and logout clears sessions from all known backend hosts.

Password-reset email is intentionally not exposed as a dead/fake action. Add it only when a real transactional email flow is configured.

## Devices and orientation
The target supports iPhone and iPad (`TARGETED_DEVICE_FAMILY = 1,2`). Layout responds to the actual window size, which also covers iPad Split View and Stage Manager.

- iPhone: portrait + landscape left/right
- iPad: portrait + upside-down + landscape left/right
- Landscape player/auth use intentional split compositions instead of moving controls arbitrarily
- Bottom navigation and mini-player remain anchored to the bottom safe area
- Artwork uses aspect-fit presentation rather than crop-to-fill

## Player / Premium
- Queue-aware previous/next, shuffle, repeat and seek
- Horizontal artwork swipe for previous/next
- Audio interruption and unplugged-headphone handling
- Premium-gated background playback / Lock Screen commands
- Premium-gated subtitles and translations
- Premium-gated offline audio use and downloads
- Premium-gated in-app AirPlay route picker
- Offline files are excluded from device backup

Premium product IDs:
- `app.muwa.nasheeds.premium.monthly`
- `app.muwa.nasheeds.premium.yearly`

## Subtitles
The native subtitle manager talks to `/_api/transcribe`, caches results on-device, and supports timed Arabic phrases/words plus Russian and English translations. No lyrics are fabricated locally.

## Publication flow
Authenticated users can select an audio file and optional cover natively. The client requests private presigned uploads from `/_api/publicationUpload`, uploads bytes directly to private storage, then uploads `submission.json` last as the completion marker. Local state becomes “На модерации” only after all required uploads succeed.

## App icon
The archive contains an opaque production-format 1024×1024 icon at:

`Resources/Assets.xcassets/AppIcon.appiconset/AppIcon-1024.png`

The same artwork is available as `AppMark` for launch/auth UI. Xcode generates all device icon renditions for the signed IPA from AppIcon.

## Build identity
- Bundle ID: `app.muwa.nasheeds`
- Version: `1.4.0`
- Build: `8`
- Deployment target: iOS/iPadOS 17+

## Verification
Run:

```bash
./verify_project.sh
```

It parses every Swift file, validates plist/project/assets, verifies AppIcon format, confirms all sources/resources are in the Xcode project, checks native-only UI/HTTPS, and validates release/device settings. On a Mac with Xcode it additionally asks `xcodebuild` to load the project/scheme.

See `AUDIT_REPORT.md` for the current full audit and the small set of external release tasks that cannot be completed from a Linux environment.
