# Muwa Auth/Profile canonical native reference

This is a SwiftUI-only implementation reference. Do not reproduce these screens as HTML, CSS, React, WKWebView, or a hosted web page.

Approved copy:

- Welcome headline: **Нашиды без музыки**
- Welcome subtitle: **Слушайте нашиды, которые приближают к Аллаху**
- Welcome support copy: **Сохраняйте любимые нашиды и возвращайтесь к ним снова.**
- Registration title: **Создайте аккаунт**
- Registration description: **Откройте аккаунт в Muwa, чтобы сохранять любимые нашиды и пользоваться всеми возможностями приложения**
- Registration confirmation: **Ваш аккаунт успешно создан. Теперь вы можете слушать нашиды, сохранять избранное и пользоваться всеми возможностями Muwa.**
- Use **записи** instead of **треки** in user-facing copy where a generic noun is required.

The visual reference is `Auth-Profile-Reference-v2.png`.
